---
title: "My Second Post"
publishDate: "12 June 2022"
description: "Another example post for Astro Cactus, this time written in a plain markdown file"
tags: ["example", "blog"]
---

## This is a post made with Markdown

```js
// Example JavaScript
function returnSeven() {
	return 7;
}
```
