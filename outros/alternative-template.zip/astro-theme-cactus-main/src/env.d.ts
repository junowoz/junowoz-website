/// <reference path="../.astro/types.d.ts" />
/// <reference types="@astrojs/image/client" />
